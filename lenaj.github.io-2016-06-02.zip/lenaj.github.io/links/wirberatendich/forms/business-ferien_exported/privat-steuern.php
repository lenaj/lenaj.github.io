Content-Type: multipart/form-data; boundary=---------------------------71852176515714
Content-Length: 1900

-----------------------------71852176515714
Content-Disposition: form-data; name="text1"

fgfdgfd
-----------------------------71852176515714
Content-Disposition: form-data; name="text2"

gfdgfgfg
-----------------------------71852176515714
Content-Disposition: form-data; name="text3"

gfdgfdg
-----------------------------71852176515714
Content-Disposition: form-data; name="text4"

fdgf
-----------------------------71852176515714
Content-Disposition: form-data; name="text6"

fgfdgf
-----------------------------71852176515714
Content-Disposition: form-data; name="text7"

5454545
-----------------------------71852176515714
Content-Disposition: form-data; name="text8"

5454545
-----------------------------71852176515714
Content-Disposition: form-data; name="text9"

lenageru@rambler.ru
-----------------------------71852176515714
Content-Disposition: form-data; name="text10"

lenageru@rambler.ru
-----------------------------71852176515714
Content-Disposition: form-data; name="text11"

434343
-----------------------------71852176515714
Content-Disposition: form-data; name="text12"

4343434
-----------------------------71852176515714
Content-Disposition: form-data; name="textarea13"


-----------------------------71852176515714
Content-Disposition: form-data; name="text14"

34343
-----------------------------71852176515714
Content-Disposition: form-data; name="fb_form_custom_html"


-----------------------------71852176515714
Content-Disposition: form-data; name="fb_form_embedded"


-----------------------------71852176515714
Content-Disposition: form-data; name="fb_js_enable"

1
-----------------------------71852176515714
Content-Disposition: form-data; name="fb_url_embedded"

file%3A%2F%2F%2FD%3A%2Fwork2%2Fwirberatendich.ch%2Fversion%252012.00%2Ftagungen.html
-----------------------------71852176515714--
