<?php echo 'Access denied.'; exit(); ?>
Wed, 02 Dec 2015 11:21:14 +0000: Couldn't decode: form.cfg.php
